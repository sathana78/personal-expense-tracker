const express = require("express");

const router = express.Router();

// GET all expenses
router.get("/", (req, res) => {
    const db = req.app.locals.db;

    const { search, category, month } = req.query;

    let sql = `
        SELECT *
        FROM expenses
        WHERE 1 = 1
    `;

    const params = [];

    // Search
    if (search) {
        sql += `
            AND (
                title LIKE ?
                OR description LIKE ?
                OR category LIKE ?
            )
        `;

        const searchValue = `%${search}%`;

        params.push(searchValue);
        params.push(searchValue);
        params.push(searchValue);
    }

    // Filter category
    if (category && category !== "All") {
        sql += ` AND category = ?`;
        params.push(category);
    }

    // Filter month
    if (month) {
        sql += ` AND substr(expense_date, 1, 7) = ?`;
        params.push(month);
    }

    sql += ` ORDER BY expense_date DESC, id DESC`;

    db.all(sql, params, (err, rows) => {
        if (err) {
            return res.status(500).json({
                message: "Failed to fetch expenses",
                error: err.message
            });
        }

        res.json(rows);
    });
});

// GET single expense
router.get("/:id", (req, res) => {
    const db = req.app.locals.db;
    const { id } = req.params;

    db.get(
        "SELECT * FROM expenses WHERE id = ?",
        [id],
        (err, row) => {
            if (err) {
                return res.status(500).json({
                    message: "Failed to fetch expense",
                    error: err.message
                });
            }

            if (!row) {
                return res.status(404).json({
                    message: "Expense not found"
                });
            }

            res.json(row);
        }
    );
});

// ADD expense
router.post("/", (req, res) => {
    const db = req.app.locals.db;

    const {
        title,
        amount,
        category,
        expense_date,
        description
    } = req.body;

    if (!title || !amount || !category || !expense_date) {
        return res.status(400).json({
            message: "Title, amount, category and date are required"
        });
    }

    if (Number(amount) <= 0) {
        return res.status(400).json({
            message: "Amount must be greater than 0"
        });
    }

    const sql = `
        INSERT INTO expenses
        (title, amount, category, expense_date, description)
        VALUES (?, ?, ?, ?, ?)
    `;

    db.run(
        sql,
        [
            title,
            Number(amount),
            category,
            expense_date,
            description || ""
        ],
        function (err) {
            if (err) {
                return res.status(500).json({
                    message: "Failed to add expense",
                    error: err.message
                });
            }

            res.status(201).json({
                message: "Expense added successfully",
                id: this.lastID
            });
        }
    );
});

// UPDATE expense
router.put("/:id", (req, res) => {
    const db = req.app.locals.db;

    const { id } = req.params;

    const {
        title,
        amount,
        category,
        expense_date,
        description
    } = req.body;

    if (!title || !amount || !category || !expense_date) {
        return res.status(400).json({
            message: "Title, amount, category and date are required"
        });
    }

    if (Number(amount) <= 0) {
        return res.status(400).json({
            message: "Amount must be greater than 0"
        });
    }

    const sql = `
        UPDATE expenses
        SET
            title = ?,
            amount = ?,
            category = ?,
            expense_date = ?,
            description = ?
        WHERE id = ?
    `;

    db.run(
        sql,
        [
            title,
            Number(amount),
            category,
            expense_date,
            description || "",
            id
        ],
        function (err) {
            if (err) {
                return res.status(500).json({
                    message: "Failed to update expense",
                    error: err.message
                });
            }

            if (this.changes === 0) {
                return res.status(404).json({
                    message: "Expense not found"
                });
            }

            res.json({
                message: "Expense updated successfully"
            });
        }
    );
});

// DELETE expense
router.delete("/:id", (req, res) => {
    const db = req.app.locals.db;

    const { id } = req.params;

    db.run(
        "DELETE FROM expenses WHERE id = ?",
        [id],
        function (err) {
            if (err) {
                return res.status(500).json({
                    message: "Failed to delete expense",
                    error: err.message
                });
            }

            if (this.changes === 0) {
                return res.status(404).json({
                    message: "Expense not found"
                });
            }

            res.json({
                message: "Expense deleted successfully"
            });
        }
    );
});

// TOTAL EXPENSE
router.get("/summary/total", (req, res) => {
    const db = req.app.locals.db;

    db.get(
        "SELECT COALESCE(SUM(amount), 0) AS total FROM expenses",
        [],
        (err, row) => {
            if (err) {
                return res.status(500).json({
                    message: "Failed to calculate total",
                    error: err.message
                });
            }

            res.json({
                total: row.total
            });
        }
    );
});

// MONTHLY EXPENSE
router.get("/summary/monthly", (req, res) => {
    const db = req.app.locals.db;

    db.all(
        `
        SELECT
            substr(expense_date, 1, 7) AS month,
            SUM(amount) AS total
        FROM expenses
        GROUP BY substr(expense_date, 1, 7)
        ORDER BY month DESC
        `,
        [],
        (err, rows) => {
            if (err) {
                return res.status(500).json({
                    message: "Failed to calculate monthly expenses",
                    error: err.message
                });
            }

            res.json(rows);
        }
    );
});

module.exports = router;
