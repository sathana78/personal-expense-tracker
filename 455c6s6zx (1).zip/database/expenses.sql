CREATE TABLE IF NOT EXISTS expenses (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    title TEXT NOT NULL,
    amount REAL NOT NULL,
    category TEXT NOT NULL,
    expense_date TEXT NOT NULL,
    description TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

INSERT INTO expenses
(title, amount, category, expense_date, description)
VALUES
('Food', 150, 'Food', '2026-10-01', 'Daily food expense'),
('Transport', 80, 'Transport', '2026-10-02', 'Bus/auto transportation'),
('Shopping', 500, 'Shopping', '2026-10-03', 'Personal shopping'),
('Education', 300, 'Education', '2026-10-04', 'Study materials'),
('Entertainment', 200, 'Entertainment', '2026-10-05', 'Entertainment expense');
