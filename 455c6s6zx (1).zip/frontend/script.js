const API_URL = "/api/expenses";

let editingExpenseId = null;

// DOM elements
const expenseForm = document.getElementById("expenseForm");

const titleInput = document.getElementById("title");
const amountInput = document.getElementById("amount");
const categoryInput = document.getElementById("category");
const expenseDateInput = document.getElementById("expenseDate");
const descriptionInput = document.getElementById("description");

const searchInput = document.getElementById("searchInput");
const filterCategory = document.getElementById("filterCategory");
const filterMonth = document.getElementById("filterMonth");

const expenseTableBody = document.getElementById("expenseTableBody");

const totalExpense = document.getElementById("totalExpense");
const monthlyExpense = document.getElementById("monthlyExpense");
const totalRecords = document.getElementById("totalRecords");

const expenseCount = document.getElementById("expenseCount");

const loading = document.getElementById("loading");
const emptyMessage = document.getElementById("emptyMessage");

const monthlySummary = document.getElementById("monthlySummary");

const formTitle = document.getElementById("formTitle");
const submitButton = document.getElementById("submitButton");
const cancelButton = document.getElementById("cancelButton");

const toast = document.getElementById("toast");

// Set today's date
function setToday() {
    const today = new Date();

    const year = today.getFullYear();
    const month = String(today.getMonth() + 1).padStart(2, "0");
    const day = String(today.getDate()).padStart(2, "0");

    expenseDateInput.value = `${year}-${month}-${day}`;
}

// Format currency
function formatCurrency(amount) {
    return new Intl.NumberFormat("en-IN", {
        style: "currency",
        currency: "INR",
        minimumFractionDigits: 2
    }).format(amount);
}

// Show notification
function showToast(message, type = "success") {
    toast.textContent = message;
    toast.className = `toast show ${type}`;

    setTimeout(() => {
        toast.className = "toast";
    }, 3000);
}

// Load expenses
async function loadExpenses() {

    loading.style.display = "block";
    emptyMessage.style.display = "none";

    try {

        const search = searchInput.value.trim();
        const category = filterCategory.value;
        const month = filterMonth.value;

        const params = new URLSearchParams();

        if (search) {
            params.append("search", search);
        }

        if (category && category !== "All") {
            params.append("category", category);
        }

        if (month) {
            params.append("month", month);
        }

        const url = `${API_URL}?${params.toString()}`;

        const response = await fetch(url);

        if (!response.ok) {
            throw new Error("Failed to load expenses");
        }

        const expenses = await response.json();

        displayExpenses(expenses);

        expenseCount.textContent =
            `${expenses.length} expense${expenses.length !== 1 ? "s" : ""}`;

    } catch (error) {

        console.error(error);

        showToast(
            "Unable to load expenses",
            "error"
        );

    } finally {

        loading.style.display = "none";
    }
}

// Display expenses
function displayExpenses(expenses) {

    expenseTableBody.innerHTML = "";

    if (expenses.length === 0) {

        emptyMessage.style.display = "block";

        return;
    }

    emptyMessage.style.display = "none";

    expenses.forEach((expense) => {

        const row = document.createElement("tr");

        row.innerHTML = `
            <td>
                <div class="expense-name">
                    ${escapeHTML(expense.title)}
                </div>

                ${
                    expense.description
                        ? `<div class="description">
                            ${escapeHTML(expense.description)}
                           </div>`
                        : ""
                }
            </td>

            <td>
                <span class="category-badge">
                    ${escapeHTML(expense.category)}
                </span>
            </td>

            <td>
                ${formatDate(expense.expense_date)}
            </td>

            <td>
                <span class="amount">
                    ${formatCurrency(expense.amount)}
                </span>
            </td>

            <td>
                <div class="action-buttons">

                    <button
                        class="btn btn-edit"
                        onclick="editExpense(${expense.id})"
                    >
                        ✏️ Edit
                    </button>

                    <button
                        class="btn btn-delete"
                        onclick="deleteExpense(${expense.id})"
                    >
                        🗑️ Delete
                    </button>

                </div>
            </td>
        `;

        expenseTableBody.appendChild(row);
    });
}

// Add / Update expense
expenseForm.addEventListener("submit", async (event) => {

    event.preventDefault();

    const expenseData = {
        title: titleInput.value.trim(),
        amount: Number(amountInput.value),
        category: categoryInput.value,
        expense_date: expenseDateInput.value,
        description: descriptionInput.value.trim()
    };

    if (!expenseData.title) {
        showToast("Please enter expense name", "error");
        return;
    }

    if (!expenseData.amount || expenseData.amount <= 0) {
        showToast("Please enter a valid amount", "error");
        return;
    }

    if (!expenseData.category) {
        showToast("Please select a category", "error");
        return;
    }

    if (!expenseData.expense_date) {
        showToast("Please select a date", "error");
        return;
    }

    try {

        let response;

        if (editingExpenseId) {

            response = await fetch(
                `${API_URL}/${editingExpenseId}`,
                {
                    method: "PUT",
                    headers: {
                        "Content-Type": "application/json"
                    },
                    body: JSON.stringify(expenseData)
                }
            );

        } else {

            response = await fetch(
                API_URL,
                {
                    method: "POST",
                    headers: {
                        "Content-Type": "application/json"
                    },
                    body: JSON.stringify(expenseData)
                }
            );
        }

        const result = await response.json();

        if (!response.ok) {
            throw new Error(result.message || "Operation failed");
        }

        showToast(
            editingExpenseId
                ? "Expense updated successfully"
                : "Expense added successfully"
        );

        resetForm();

        await loadExpenses();
        await loadSummary();
        await loadMonthlySummary();

    } catch (error) {

        console.error(error);

        showToast(
            error.message,
            "error"
        );
    }
});

// Edit expense
async function editExpense(id) {

    try {

        const response = await fetch(`${API_URL}/${id}`);

        const expense = await response.json();

        if (!response.ok) {
            throw new Error(
                expense.message || "Failed to get expense"
            );
        }

        editingExpenseId = id;

        titleInput.value = expense.title;
        amountInput.value = expense.amount;
        categoryInput.value = expense.category;
        expenseDateInput.value = expense.expense_date;
        descriptionInput.value = expense.description || "";

        formTitle.textContent = "Edit Expense";

        submitButton.textContent = "💾 Update Expense";

        cancelButton.style.display = "inline-block";

        window.scrollTo({
            top: 0,
            behavior: "smooth"
        });

    } catch (error) {

        console.error(error);

        showToast(
            "Unable to load expense",
            "error"
        );
    }
}

// Delete expense
async function deleteExpense(id) {

    const confirmed = confirm(
        "Are you sure you want to delete this expense?"
    );

    if (!confirmed) {
        return;
    }

    try {

        const response = await fetch(
            `${API_URL}/${id}`,
            {
                method: "DELETE"
            }
        );

        const result = await response.json();

        if (!response.ok) {
            throw new Error(
                result.message || "Failed to delete expense"
            );
        }

        showToast("Expense deleted successfully");

        await loadExpenses();
        await loadSummary();
        await loadMonthlySummary();

    } catch (error) {

        console.error(error);

        showToast(
            error.message,
            "error"
        );
    }
}

// Reset form
function resetForm() {

    expenseForm.reset();

    editingExpenseId = null;

    formTitle.textContent = "Add Expense";

    submitButton.textContent = "➕ Add Expense";

    cancelButton.style.display = "none";

    setToday();
}

// Cancel edit
function cancelEdit() {
    resetForm();
}

// Clear filters
function clearFilters() {

    searchInput.value = "";
    filterCategory.value = "All";
    filterMonth.value = "";

    loadExpenses();
}

// Load total summary
async function loadSummary() {

    try {

        const totalResponse = await fetch(
            `${API_URL}/summary/total`
        );

        const totalData = await totalResponse.json();

        totalExpense.textContent =
            formatCurrency(totalData.total);

        // Current month
        const today = new Date();

        const currentMonth =
            `${today.getFullYear()}-${String(
                today.getMonth() + 1
            ).padStart(2, "0")}`;

        const monthResponse = await fetch(
            `${API_URL}?month=${currentMonth}`
        );

        const monthExpenses = await monthResponse.json();

        const currentMonthTotal = monthExpenses.reduce(
            (sum, expense) => sum + Number(expense.amount),
            0
        );

        monthlyExpense.textContent =
            formatCurrency(currentMonthTotal);

        totalRecords.textContent =
            monthExpenses.length;

    } catch (error) {

        console.error(error);
    }
}

// Load monthly summary
async function loadMonthlySummary() {

    try {

        const response = await fetch(
            `${API_URL}/summary/monthly`
        );

        const data = await response.json();

        monthlySummary.innerHTML = "";

        if (data.length === 0) {

            monthlySummary.innerHTML = `
                <div class="empty-message">
                    No monthly data available.
                </div>
            `;

            return;
        }

        data.forEach((item) => {

            const div = document.createElement("div");

            div.className = "month-summary-item";

            div.innerHTML = `
                <span class="month-name">
                    ${formatMonth(item.month)}
                </span>

                <span class="month-total">
                    ${formatCurrency(item.total)}
                </span>
            `;

            monthlySummary.appendChild(div);
        });

    } catch (error) {

        console.error(error);
    }
}

// Format date
function formatDate(dateString) {

    const date = new Date(`${dateString}T00:00:00`);

    return date.toLocaleDateString("en-IN", {
        day: "2-digit",
        month: "short",
        year: "numeric"
    });
}

// Format month
function formatMonth(monthString) {

    const date = new Date(`${monthString}-01T00:00:00`);

    return date.toLocaleDateString("en-IN", {
        month: "long",
        year: "numeric"
    });
}

// Prevent HTML injection
function escapeHTML(value) {

    return String(value)
        .replaceAll("&", "&amp;")
        .replaceAll("<", "&lt;")
        .replaceAll(">", "&gt;")
        .replaceAll('"', "&quot;")
        .replaceAll("'", "&#039;");
}

// Search with small delay
let searchTimer;

searchInput.addEventListener("input", () => {

    clearTimeout(searchTimer);

    searchTimer = setTimeout(() => {
        loadExpenses();
    }, 300);
});

filterCategory.addEventListener(
    "change",
    loadExpenses
);

filterMonth.addEventListener(
    "change",
    loadExpenses
);

// Initialize application
async function initializeApp() {

    setToday();

    await loadExpenses();

    await loadSummary();

    await loadMonthlySummary();
}

initializeApp();
